(readme.txt) HelloNew program, Chapter 10

Use the customized version of make16.bat found in the current directory when you assemble and link the HelloNew.asm program.
