// findarr.h

extern "C" {

bool FindArray( long n, long array[], long count );
// Assembly language version

bool FindArray2( long n, long array[], long count );
// CPP version
}