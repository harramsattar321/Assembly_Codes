(readme.txt) Bsearch program, Chapter 9

Run the customized version of make32.bat found in the current directory when you assemble and link this program.
